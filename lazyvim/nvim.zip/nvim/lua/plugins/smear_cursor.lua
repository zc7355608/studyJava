return {
  {
    "sphamba/smear-cursor.nvim",
    opts = {
      -- -- 拖尾长度：数值越小，拖尾越短，视觉残留越弱
      -- trail_length = 8,      -- 默认通常是 12 或更大
      -- -- 拖尾淡出时间：数值越小，拖尾消失得越快
      -- fade_time = 150,       -- 默认通常是 200ms
      -- -- 修复目标位置闪烁的问题，保持显示稳定
      -- hide_target_hack = true,
      -- -- 拖尾透明度：数值越大，拖尾越淡
      -- -- 0 为完全不透明，1 为完全透明（不可见）
      -- opacity = 0.7,
      -- -- 光标样式是否跟随拖尾
      -- legacy_computing = false,
    },
  },
}
