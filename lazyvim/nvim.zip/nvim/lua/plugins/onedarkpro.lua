return {
  {
    "olimorris/onedarkpro.nvim",
    priority = 1000, -- 确保主题优先加载，避免闪烁
  },
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "onedark",
    }
  }
}
